package consistent_hashing;

import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

public class HashUtil {

	private static SortedMap <Integer, Server> servers = new TreeMap <Integer, Server>();
	
	public static void loadData(List <Entry> entryList){
		for (Entry e : entryList){
			int code = routerServerHashCode(e.name);
			Server server = servers.get(code);
			server.storeValue.put(e.name, e.value);
			System.out.println(e.name+"("+getHash(e.name)+") is store at "+server.name+"("+code+")");
		}
	}
	
	public static void loadServers(List <String> serverList){
		for (String s : serverList){
			Server server = new Server(s);
			for (int i = 0; i < 10 ;i++){
				servers.put(getHash(s+"@"+i), server);
				System.out.println(getHash(s+"@"+i)+"------"+s+"@"+i);
			}
		}
	}
	
	public static String getValueByEntryIP(String IP){
		Server server = servers.get(routerServerHashCode(IP));
		Map map = server.getStoreValue();
		System.out.println(IP+" to get value from "+ server.name);
		return (String) map.get(IP);
	}
	
	private static int routerServerHashCode(String IP){
		int hashCode = getHash(IP);
		Server server = null;
		if (!servers.containsKey(hashCode)){
			SortedMap map = servers.tailMap(hashCode);
			int key = (int) (map.isEmpty() ? servers.firstKey():map.firstKey());
			return key;
		}else {
			return hashCode;
		}
	}
	
	public static void removeServer(String address){
		for (int i = 0; i < 10 ;i++){
			servers.remove(getHash(address+"@"+i));
		}
	}
	
	public static void showAllServers(){
		
		for (SortedMap.Entry<Integer, Server> entry : servers.entrySet()){
			System.out.println("key: "+entry.getKey()+" value: "+entry.getValue().name);
		}
		System.out.println("server size : "+servers.size());
	
	}
	
	private static int getHash(String str)
	    {
	        final int p = 16777619;
	        int hash = (int)2166136261L;
	        for (int i = 0; i < str.length(); i++)
	            hash = (hash ^ str.charAt(i)) * p;
	        hash += hash << 13;
	        hash ^= hash >> 7;
	        hash += hash << 3;
	        hash ^= hash >> 17;
	        hash += hash << 5;

	        if (hash < 0)
	            hash = Math.abs(hash);
	        return hash;
	    }
	 
	 public static void main(String[] args) {
		 System.out.println(getHash("12.222.23.16@1"));
		 System.out.println(getHash("12.222.23.16@2"));
		 System.out.println(getHash("12.222.23.16@3"));
		 System.out.println(getHash("12.222.23.16@4"));
		 showAllServers();
	 }
}
