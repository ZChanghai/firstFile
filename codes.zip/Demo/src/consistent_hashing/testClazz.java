package consistent_hashing;

import java.util.SortedMap;
import java.util.TreeMap;

public class testClazz {

	public static void main(String[] args) {
		String A = "A";
		String B = "B";
		B.equals("");
		TreeMap<String, String> tree = new TreeMap<String, String>();
		tree.put("83", "83");
		tree.put("34", "34");
		tree.put("54", "54");
		tree.put("24", "24");
		tree.put("14", "14");
		tree.put("33", "33");
		tree.put("37", "37");
		SortedMap <String,String> sort = tree.tailMap("34");
		System.out.println(A.hashCode());
		System.out.println(A.hashCode());
	}

}
