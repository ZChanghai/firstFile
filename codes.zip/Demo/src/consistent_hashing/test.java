package consistent_hashing;

import java.util.ArrayList;
import java.util.List;

public class test {

	public static void main(String[] args) {
		
		List list = new ArrayList();
		
		list.add("12.222.23.16");
		list.add("12.222.23.36");
		list.add("12.222.23.56");
		list.add("12.222.23.76");
		
		HashUtil.loadServers(list);
		HashUtil.showAllServers();
		
		List aa = new ArrayList();
		aa.add(new Entry("10.248.155.16","16"));
		aa.add(new Entry("10.248.155.36","36"));
		aa.add(new Entry("10.248.155.56","56"));
		aa.add(new Entry("10.248.155.76","76"));
		HashUtil.loadData(aa);
		
		System.out.println(HashUtil.getValueByEntryIP("10.248.155.16"));
		System.out.println(HashUtil.getValueByEntryIP("10.248.155.36"));
		System.out.println(HashUtil.getValueByEntryIP("10.248.155.56"));
		System.out.println(HashUtil.getValueByEntryIP("10.248.155.76"));
		
		HashUtil.removeServer("12.222.23.56");
		HashUtil.showAllServers();
		System.out.println(HashUtil.getValueByEntryIP("10.248.155.16"));
		System.out.println(HashUtil.getValueByEntryIP("10.248.155.36"));
		System.out.println(HashUtil.getValueByEntryIP("10.248.155.56"));
		System.out.println(HashUtil.getValueByEntryIP("10.248.155.76"));
		
		int i = 2;
		i = i+2;
		System.out.println(i);
		
	}

}
