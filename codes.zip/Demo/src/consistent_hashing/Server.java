package consistent_hashing;

import java.util.HashMap;
import java.util.Map;

public class Server {
	
	String name;
	
	public Server (String name){
		this.name= name;
		this.storeValue = new HashMap();
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map getStoreValue() {
		return storeValue;
	}

	public void setStoreValue(Map storeValue) {
		this.storeValue = storeValue;
	}

	Map storeValue;
}
