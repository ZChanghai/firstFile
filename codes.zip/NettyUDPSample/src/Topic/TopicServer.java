package Topic;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioDatagramChannel;

import java.io.IOException;
import java.io.RandomAccessFile;

import ChannelHandler.RequestLogEncode;
import Entity.RequestEntity;

public class TopicServer {

	public static void main(String[] args) {
		EventLoopGroup workerGroup = new NioEventLoopGroup();
		Channel ch = null;
        try {
            Bootstrap b = new Bootstrap();
            b.group(workerGroup)
                    .channel(NioDatagramChannel.class)
                    .option(ChannelOption.SO_BROADCAST, true)
                    .handler(new RequestLogEncode());
            ch = b.bind(0).sync().channel();
            long pointer = 0;
            for (;;) {
            	RandomAccessFile ra = new RandomAccessFile("src/log.txt","r");
            	long size = ra.length();
            	if (size>pointer){
            		ra.seek(pointer);
            		String logContent;
            		while((logContent = ra.readLine())!= null) {
            			if (!logContent.equals("")){
            				RequestEntity request = new RequestEntity(logContent);
            				ch.writeAndFlush(request);
            			}
            			
            		}
            		pointer = ra.getFilePointer();
            		ra.close();
//            		ch.closeFuture().sync();
            	}else if(size < pointer){
            		pointer = size;
            	}
            	try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
		        	Thread.interrupted();
					break;
				} 
            }
           
        } catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e1) {
			
			e1.printStackTrace();
		} finally {
            workerGroup.shutdownGracefully();
        }
		
	}

}
