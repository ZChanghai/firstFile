package util;

import io.netty.util.CharsetUtil;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class concurrentWriteLog {
	
//	private static RandomAccessFile raf = null;
//	private static RandomAccessFile logFile = null;
	private static Lock lock = new ReentrantLock(false);
	
//	static {
//		try {
//			raf = new RandomAccessFile("src/writeLog.txt", "rw");
//			logFile = new RandomAccessFile("src/log.txt", "rw");
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		}
//	}
	
	public static void writeBackupLog(String text){
		lock.lock();
		try {
			RandomAccessFile raf = new RandomAccessFile("src/writeLog.txt", "rw");
			writeProcess(raf,text);
			raf.close();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			lock.unlock();
		}
		
	}
	
	public static void writeLog(String log){
		lock.lock();
		try {
			RandomAccessFile logFile = new RandomAccessFile("src/log.txt", "rw");
			writeProcess(logFile,log);
			logFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			lock.unlock();
		}
		
	}
	
	public static void writeBackupLog1(String text){
		lock.lock();
		try {
			RandomAccessFile raf = new RandomAccessFile("src/writeLog1.txt", "rw");
			writeProcess(raf,text);
			raf.close();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			lock.unlock();
		}
		
	}
	
	private static void writeProcess(RandomAccessFile file,String log) throws IOException{
		file.seek(file.length());
		if (file.length()>0){
			file.write(0x0d);
		}
		file.write(log.getBytes(CharsetUtil.UTF_8));
	}

}
