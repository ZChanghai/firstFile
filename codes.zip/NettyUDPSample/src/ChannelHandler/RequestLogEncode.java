package ChannelHandler;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.socket.DatagramPacket;
import io.netty.handler.codec.MessageToMessageEncoder;
import io.netty.util.CharsetUtil;

import java.net.InetSocketAddress;
import java.util.List;

import Entity.RequestEntity;

public class RequestLogEncode extends MessageToMessageEncoder<RequestEntity>{

	@Override
	protected void encode(ChannelHandlerContext ctx, RequestEntity msg,
			List<Object> out) throws Exception {
		byte[] content = msg.getLogContent().getBytes(CharsetUtil.UTF_8); 
		ByteBuf byt =ctx.alloc().buffer(msg.getContentLength()+content.length);
		byt.writeInt(msg.getContentLength());
		byt.writeBytes(content);
//		byt1.writeInt(msg.getContentLength());
//		byt1.writeBytes(content);
		ByteBuf byt1 = byt.copy();
		ByteBuf byt2 = byt1.copy();
		out.add(new DatagramPacket(byt, new InetSocketAddress("127.0.0.1", 8081)));
		out.add(new DatagramPacket(byt1, new InetSocketAddress("10.248.155.76", 8082)));
		out.add(new DatagramPacket(byt2, new InetSocketAddress("10.248.155.110", 8082)));
	}

}
