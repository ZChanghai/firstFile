package ChannelHandler;

import java.util.List;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.socket.DatagramPacket;
import io.netty.handler.codec.MessageToMessageDecoder;
import io.netty.util.CharsetUtil;

public class MoniterDecoder extends MessageToMessageDecoder<DatagramPacket>{

	@Override
	protected void decode(ChannelHandlerContext ctx, DatagramPacket msg,
			List<Object> out) throws Exception {
		ByteBuf data = msg.content();
		System.out.println("data is come form :"+msg.sender().getHostName()+" port is "+msg.sender().getPort());
		if (data.readableBytes()>4){
			int contentLength = data.readInt();
			System.out.println("contentLength" +contentLength);
			if (data.readableBytes()>=contentLength){
				String content = data.readBytes(contentLength).toString(CharsetUtil.UTF_8);
				System.out.println("content" +content);
				out.add(content);
			}
		}
	}

}
