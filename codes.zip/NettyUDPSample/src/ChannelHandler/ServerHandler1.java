package ChannelHandler;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import util.concurrentWriteLog;

public class ServerHandler1 extends SimpleChannelInboundHandler<String>{

	@Override
	protected void channelRead0(ChannelHandlerContext ctx, String msg)
			throws Exception {
			System.out.println(Thread.currentThread().getName() +" inside serverHandler");
			concurrentWriteLog.writeBackupLog1(msg);
			System.out.println(Thread.currentThread().getName() +" exit serverHandler");
	}

}
