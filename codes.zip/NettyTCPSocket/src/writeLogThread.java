import util.concurrentWriteLog;

public class writeLogThread extends Thread{
	private String text;
	
	public writeLogThread(String text){
		this.text = text;
	}
	
	 @Override
     public void run() {
		 concurrentWriteLog.writeLog(text);
	 }
}
