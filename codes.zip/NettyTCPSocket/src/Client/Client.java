package Client;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

import java.io.IOException;
import java.io.RandomAccessFile;

import ChannelHandler.requestLogEncode;
import Entity.RequestEntity;

public class Client {

	public static void main(String[] args) {
		EventLoopGroup workerGroup = new NioEventLoopGroup();
		Channel ch = null;
        try {
            Bootstrap b = new Bootstrap();
            b.group(workerGroup)
                    .channel(NioSocketChannel.class)
                    .option(ChannelOption.TCP_NODELAY, true)
                    .handler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel ch) throws Exception {
                            ChannelPipeline p = ch.pipeline();
                            p.addLast(new requestLogEncode());
                        }
                    });
            ch = b.connect("127.0.0.1", 8080).sync().channel();
            long pointer = 0;
            for (;;) {
            	RandomAccessFile ra = new RandomAccessFile("src/log.txt","r");
            	long size = ra.length();
            	if (size>pointer){
            		ra.seek(pointer);
            		String logContent;
            		while((logContent = ra.readLine())!= null) {
            			if (!logContent.equals("")){
            				RequestEntity request = new RequestEntity(logContent);
            				ch.writeAndFlush(request);
            			}
            			
            		}
            		pointer = ra.getFilePointer();
            		ra.close();
//            		ch.closeFuture().sync();
            	}else if(size < pointer){
            		pointer = size;
            	}
            	Thread.sleep(1000);
            }
           
        } catch (InterruptedException e) {
        	Thread.interrupted();
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
            workerGroup.shutdownGracefully();
        }
	}	

}
