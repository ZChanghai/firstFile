package ChannelHandler;

import java.util.List;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.util.CharsetUtil;

public class ServerDecoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf in,
			List<Object> out) throws Exception {
		System.out.println("inside serverDecoder");
		if (in.readableBytes()>4){
			int contentLength = in.readInt();
			System.out.println("contentLength" +contentLength);
			if (in.readableBytes()>=contentLength){
				String content = in.readBytes(contentLength).toString(CharsetUtil.UTF_8);
				System.out.println("content" +content);
				out.add(content);
			}
		}
		System.out.println("exit serverDecoder");
	}

}
