package PriorBlockQueueSample;

import java.util.List;
import java.util.concurrent.BlockingQueue;


public class getMember implements Runnable {
	
	private BlockingQueue <Member> queue;
	private List <Member>list;
	
	public getMember(BlockingQueue <Member> queue,List<Member> list){
		this.queue = queue;
		this.list = list;
	}

	@Override
	public void run() {
		Member m = queue.poll();
		if (m != null){
			list.add(m);
//			String result = "Thread(%s) took name= %s ,status= %s, value=%d\n";
//			System.out.printf(result, Thread.currentThread().getName(),m.getName(),m.getStatus(),m.getValue());
		}else{
//			String result1 = "Thread(%s) didn't took any element!";
//			System.out.printf(result1, Thread.currentThread().getName());
		}
	}

}
