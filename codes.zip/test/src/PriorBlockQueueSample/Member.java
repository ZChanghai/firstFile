package PriorBlockQueueSample;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Member implements Comparable<Member>{
	
	public Member(String name,String status,int value){
		this.name = name;
		this.status = status;
		this.value = value;
	}
	
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	private String status;
	
	private int value;

	@Override  
    public String toString() {  
        return "name:"+ name + ",status=" + status + ",value="+value;  
    }  
	
	@Override
	public int compareTo(Member o) {
		int result = 0;
		if (this.status.equals("vip") && o.status.equals("vip")){
			result = this.value > o.value ? -1:this.value == o.value ? 0:1;
		}else{
			result = -1;
		}
		return result;
	}
	
	public static void main(String[] args) {
		
		List <Member> memberList = new ArrayList<Member>();
		memberList.add(new Member("wangwu","normal",1000));
		memberList.add(new Member("wangwu1","normal",2000));
		memberList.add(new Member("wangwu2","normal",4000));
		memberList.add(new Member("wangwu3","normal",5000));
		memberList.add(new Member("wangwu4","normal",6000));
		memberList.add(new Member("zhangsan","vip",10000));
		memberList.add(new Member("zhang","vip",10001));
		memberList.add(new Member("zhang11","vip",10002));
		memberList.add(new Member("lisi","vip",200));
//		System.out.println(memberList);
		Collections.sort(memberList);
		for (Member entry : memberList){
			String result = "name= %s ,status= %s, value=%d\n";
//			System.out.println("name:"+ entry.name + ",status=" + entry.status + ",value="+entry.value);
			System.out.printf(result, entry.name,entry.status,entry.value);
		}
	}

}
