package PriorBlockQueueSample;

import java.util.concurrent.BlockingQueue;

public class insertMemberWithSingleThread implements Runnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	private BlockingQueue<Member> queue= null;
	
	public insertMemberWithSingleThread(BlockingQueue <Member> queue){
		this.queue = queue;
	}

	@Override
	public void run() {
		try {
			queue.put(new Member("wangwu","normal",1000));
			queue.put(new Member("wangwu1","normal",2000));
			queue.put(new Member("wangwu2","normal",4000));
			queue.put(new Member("zhang","vip",10001));
			queue.put(new Member("wangwu4","normal",6000));
			queue.put(new Member("zhangsan","vip",10000));
			queue.put(new Member("wangwu3","normal",5000));
			queue.put(new Member("zhang11","vip",10002));
			queue.put(new Member("lisi","vip",200));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
