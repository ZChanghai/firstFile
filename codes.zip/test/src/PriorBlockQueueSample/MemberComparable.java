package PriorBlockQueueSample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MemberComparable implements Comparator<Member> {

	@Override
	public int compare(Member o1, Member o2) {
		int result = o1.getStatus().compareTo(o2.getStatus())>0?-1:o1.getStatus().equals(o2.getStatus())?0:1;
		if (result == 0){
			result = o1.getValue() > o2.getValue() ? -1:o1.getValue() == o2.getValue() ? 0:1;
		}
		return result;
	}
	
	public static void main(String[] args) {
		
		List <Member> memberList = new ArrayList<Member>();
		memberList.add(new Member("wangwu","normal",1000));
		memberList.add(new Member("wangwu1","normal",2000));
		memberList.add(new Member("wangwu2","normal",4000));
		memberList.add(new Member("wangwu3","normal",5000));
		memberList.add(new Member("wangwu4","normal",6000));
		memberList.add(new Member("zhangsan","vip",10000));
		memberList.add(new Member("zhang","vip",10001));
		memberList.add(new Member("zhang11","vip",10002));
		memberList.add(new Member("lisi","vip",200));
//		System.out.println(memberList);
		Collections.sort(memberList,new MemberComparable());
		for (Member entry : memberList){
			String result = "name= %s ,status= %s, value=%d\n";
//			System.out.println("name:"+ entry.name + ",status=" + entry.status + ",value="+entry.value);
			System.out.printf(result, entry.getName(),entry.getStatus(),entry.getValue());
		}
		System.out.println("wormal".compareTo("vip"));
	}

}
