package PriorBlockQueueSample;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.PriorityBlockingQueue;

public class PriorityBlockingQueueSample {

	public static void main(String[] args) throws InterruptedException {
		ExecutorService fixedThreadPool = Executors.newFixedThreadPool(4);
		BlockingQueue <Member>queue = new PriorityBlockingQueue<Member>(9,new MemberComparable());
//		BlockingQueue <Member>queue = new ArrayBlockingQueue<Member>(9);
		queue.add(new Member("wangwu","normal",1000));
		queue.add(new Member("wangwu1","normal",2000));
		queue.add(new Member("wangwu2","normal",4000));
		queue.add(new Member("wangwu3","normal",5000));
		queue.add(new Member("wangwu4","normal",6000));
		queue.add(new Member("zhangsan","vip",10000));
		queue.add(new Member("zhang","vip",10001));
		queue.add(new Member("zhang11","vip",10002));
		queue.add(new Member("lisi","vip",200));
//		insertMemberWithSingleThread thread = new insertMemberWithSingleThread(queue);
//		new Thread(thread).start();
		List<Member> list = new ArrayList<Member>();
		for (int i =0 ;i<10;i++){
			fixedThreadPool.execute(new getMember(queue,list));
		}
		fixedThreadPool.shutdown();
		
		for (Member m:list){
			String result = "name= %s ,status= %s, value=%d\n";
			System.out.printf(result, m.getName(),m.getStatus(),m.getValue());
		}
	}

}
