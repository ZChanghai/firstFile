package NettyTCPSocket.ChannelHandle;

import java.util.List;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.util.CharsetUtil;

public class ServerDecoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf in,
			List<Object> out) throws Exception {
		if (in.readableBytes()>4){
			int contentLength = in.readInt();
			if (in.readableBytes()>=contentLength){
				String content = in.readBytes(contentLength).toString(CharsetUtil.UTF_8);
				out.add(content);
			}
		}
	}

}
