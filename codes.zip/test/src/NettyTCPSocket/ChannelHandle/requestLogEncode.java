package NettyTCPSocket.ChannelHandle;

import NettyTCPSocket.Entity.RequestEntity;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import io.netty.util.CharsetUtil;

public class requestLogEncode extends MessageToByteEncoder<RequestEntity>{

	@Override
	protected void encode(ChannelHandlerContext ctx, RequestEntity msg, ByteBuf out)
			throws Exception {
		out.writeInt(msg.getContentLength());
		out.writeBytes(msg.getLogContent().getBytes(CharsetUtil.UTF_8));
	}

}
