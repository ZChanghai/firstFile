package NettyTCPSocket.ChannelHandle;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.util.CharsetUtil;

public class ServerHandler extends SimpleChannelInboundHandler<String>{

	@Override
	protected void channelRead0(ChannelHandlerContext ctx, String msg)
			throws Exception {
		RandomAccessFile ra = null;
		try {
			ra = new RandomAccessFile("src/FileAccess/storeLog.txt","rw");
			ra.seek(ra.length());
			if (ra.length()>0){
				ra.write(0x0d);
			}
			ra.write(msg.getBytes(CharsetUtil.UTF_8));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				if (ra != null)
				ra.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
