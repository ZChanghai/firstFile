package NettyTCPSocket.Entity;

import io.netty.util.CharsetUtil;

public class RequestEntity {
	private String logContent;
	public String getLogContent() {
		return logContent;
	}
	public void setLogContent(String logContent) {
		this.logContent = logContent;
	}
	public int getContentLength() {
		return contentLength;
	}
	public void setContentLength(int contentLength) {
		this.contentLength = contentLength;
	}
	private int contentLength;
	
	public RequestEntity(String logConent){
		this.logContent = logConent;
		this.contentLength = logContent.getBytes(CharsetUtil.UTF_8).length;
	}
}
