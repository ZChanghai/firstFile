package NettyTCPSocket.Client;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;

import NettyTCPSocket.ChannelHandle.requestLogEncode;
import NettyTCPSocket.Entity.RequestEntity;

import com.ssga.fitp.handler.ClientHandler;
import com.ssga.fitp.handler.RequestEncoder;
import com.ssga.fitp.handler.ResponseDecoder;
import com.ssga.fitp.model.FitpRequest;

public class Client {

	public static void main(String[] args) throws InterruptedException, IOException {
		EventLoopGroup workerGroup = new NioEventLoopGroup();
		Channel ch = null;
		RandomAccessFile ra = null;
        try {
            Bootstrap b = new Bootstrap();
            b.group(workerGroup)
                    .channel(NioSocketChannel.class)
                    .option(ChannelOption.TCP_NODELAY, true)
                    .handler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel ch) throws Exception {
                            ChannelPipeline p = ch.pipeline();
                            p.addLast(new requestLogEncode());
                        }
                    });
            ChannelFuture f = b.connect("127.0.0.1", 8080).sync();
            ch = f.channel();
            ChannelFuture lastWriteFuture = null;
            long pointer = 0;
            for (;;) {
            	ra = new RandomAccessFile("src/FileAccess/test.txt","r");
            	long size = ra.length();
            	if (size>pointer){
            		ra.seek(pointer);
            		String logContent = ra.readLine();
            		if (logContent ==null || logContent.equals("")){
            			continue;
            		}else {
	            		pointer = ra.getFilePointer();
	            		RequestEntity request = new RequestEntity(logContent);
	            		lastWriteFuture = ch.writeAndFlush(request);
	            		if (lastWriteFuture != null) {
	            			lastWriteFuture.sync();
	            		}
            		}
            	}else{
            		pointer = size;
            		continue;
            	}
            }
           
        } finally {
        	if (ra != null){
        		ra.close();
        	}
            workerGroup.shutdownGracefully();
        }
	}	

}
