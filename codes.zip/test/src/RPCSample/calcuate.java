package RPCSample;

public class calcuate implements calculate {

	@Override
	public int plusAction(int a, int b) {
		
		return a+b;
	}

}
