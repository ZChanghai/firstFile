package RPCSample;

public interface calculate {
	
	public int plusAction(int a, int b);

}
