package RPCSample;

public class client {
	
	public static void main(String[] args) {
		
		ProxyHandle proxy = new ProxyHandle(calculate.class,"127.0.0.1",8989);
		
		calculate ca = (calculate) proxy.getProxyInstance();
		System.out.println(ca.plusAction(1, 2));
	}

}
