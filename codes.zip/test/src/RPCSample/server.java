package RPCSample;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Method;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class server {
	
	private static ExecutorService executorService = Executors.newFixedThreadPool(20); 
	public static void export(int port) throws IOException { 
		ServerSocket servers = new ServerSocket(port); 
		while (true) { 
			final Socket socket = servers.accept(); 
			executorService.submit(new Runnable() { 
				@Override 
				public void run() { 
					try { 
						try { 
							ObjectInputStream input = new ObjectInputStream(socket.getInputStream()); 
							try { 
								String methodName = input.readUTF(); 
								String intetfaceName = input.readUTF();
								System.out.println(intetfaceName);
								Class<?>[] parameterTypes = (Class<?>[]) input.readObject(); 
								Object[] arguments = (Object[]) input.readObject(); 
								ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream()); 
								try {
									calcuate service = (calcuate) Class.forName("RPCSample.calcuate").newInstance();
									Method method = service.getClass().getMethod(methodName, parameterTypes); 
									Object result = method.invoke(service, arguments); 
									output.writeObject(result); 
									} catch (Throwable t) { 
										output.writeObject(t); 
									} finally { 
										output.close(); 
									} 
								} finally { 
								input.close(); 
								} 
							} finally { 
								socket.close(); 
							} 
						} catch (Exception e) { 
							e.printStackTrace(); 
						} 
				} 
			}); 
		}
	}
	
	public static void main(String[] args) {
		try {
			server.export(8989);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
