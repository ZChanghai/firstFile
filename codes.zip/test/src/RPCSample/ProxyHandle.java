package RPCSample;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.Socket;
import java.net.UnknownHostException;

public class ProxyHandle implements InvocationHandler {
	
	private Class object;
	
	private String host;
	
	private int port;
	
	public ProxyHandle(Class aa,String localhost,int port){
		this.object = aa;
		this.host = localhost;
		this.port = port;
	}
	
	public Object getProxyInstance(){
		return Proxy.newProxyInstance(object.getClassLoader(), new Class[]{object}, this);
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Socket socket = null;
		 try { 
			 socket = new Socket(host, port);
			 ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream()); 
			 try { 
				 output.writeUTF(method.getName());
				 output.writeUTF(object.getName());
				 output.writeObject(method.getParameterTypes()); 
				 output.writeObject(args); 
				 ObjectInputStream input = new ObjectInputStream(socket.getInputStream()); 
				 try { 
					 Object result = input.readObject(); 
					 if (result instanceof Throwable) { 
						 throw (Throwable) result; 
					 } 
					 return result; 
				 } catch (ClassNotFoundException e) {
					e.printStackTrace();
				} catch (Throwable e) {
					e.printStackTrace();
				} finally { 
					 input.close(); 
				 } 
			 }finally { 
				 output.close(); 
			 } 
		 } catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally { 
				 try {
					socket.close();
				} catch (IOException e) {
					e.printStackTrace();
				} 
		 }
		return socket;
	}

}
