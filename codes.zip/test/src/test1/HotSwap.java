package test1;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;



public class HotSwap extends ClassLoader {
	
	protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException{
		Class cls = null;
		cls = findLoadedClass(name);
		if (name.startsWith("java")){
			cls = getSystemClassLoader().loadClass(name);
		}else{
			cls = findClass(name);	
		}
		if (cls == null){
			throw new ClassNotFoundException(name);
		}
		if (resolve)
			resolveClass(cls);
		return cls;

	}
	
	protected Class<?> findClass(String name){
		String classPath = HotSwap.class.getResource("/").getPath();
		String className = name.replace(".", "/")+".class";
		File classfile = new File(classPath,className);
		return generateClass(name,classfile);
	}
	
	private Class generateClass(String name,File classfile){
		byte[] raw = null;
		try {
			InputStream in = new FileInputStream(classfile);
			raw =  new byte[(int) classfile.length()];
			in.read(raw);
			in.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return defineClass(name,raw,0,raw.length);
	}
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException, ClassNotFoundException {
		HotSwap a = new HotSwap();
		Class newClass = a.loadClass("test.test");
		Object instance = newClass.newInstance() ;
		Method sayHelloMethod = newClass.getMethod("sayHello") ;
		sayHelloMethod.invoke(instance);
		
		
	}

}
