package test1;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

public class test22 {

	public static void main(String[] args) {
		TreeMap<Integer,String> tree = new TreeMap<Integer,String>();
		tree.put(11111, "top1");
		tree.put(22222, "top2");
		tree.put(33333, "top3");
		Iterator iter = tree.entrySet().iterator();
		while(iter.hasNext()){
			Entry entry = (Entry)iter.next();
			System.out.println("key "+entry.getKey().toString());
			System.out.println("value "+entry.getValue().toString());
		}
		
		Set set = new HashSet();
		set.add("aaaa");
		set.add("bbb");
		set.add("bbb");
		Iterator itera = set.iterator();
		while(itera.hasNext()){
			String a = itera.next().toString();
			System.out.println(a);
		}
	}

}
