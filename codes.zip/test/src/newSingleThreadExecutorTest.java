import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class newSingleThreadExecutorTest {
	
	public void process(){
		
	}

	public static void main(String[] args) {
		final long start = System.currentTimeMillis();
		ExecutorService singleThreadExecutor = Executors.newSingleThreadExecutor();
		  for (int i = 0; i < 10; i++) {  
		   final int index = i;  
		   singleThreadExecutor.execute(new Runnable() {  
		    public void run() {  
		     try {  
		    	 Thread.sleep(index * 1000);  
				 System.out.println(Thread.currentThread().getName()+" is processed index: "+index);
				 if (index == 9){
					 long end = System.currentTimeMillis();
					 System.out.println(( end - start)/1000 + " seconds");
				 }
		     } catch (InterruptedException e) {  
		      e.printStackTrace();  
		     }  
		    }  
		   });  
		  }
		

	}

}
