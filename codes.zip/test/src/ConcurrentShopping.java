import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.atomic.AtomicInteger;


public class ConcurrentShopping {

	public static AtomicInteger productCount = new AtomicInteger(10);
	public static void main(String[] args) {
		int N = 4;
		CyclicBarrier barrier = new CyclicBarrier(N);
		for (int i = 0; i < N; i++)
			new ShoppingThread(barrier).start();
	}
	
	public static void ShoppingAction(int count){
		productCount.addAndGet(-count);
	}

	static class ShoppingThread extends Thread {
		private CyclicBarrier cyclicBarrier;

		public ShoppingThread(CyclicBarrier cyclicBarrier) {
			this.cyclicBarrier = cyclicBarrier;
		}

		@Override
		public void run() {
			System.out.println("thread" + Thread.currentThread().getName() + "shopping......");
			try {
				ShoppingAction(2);
				System.out.println("thread" + Thread.currentThread().getName() + "first round shopped");
				cyclicBarrier.await();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (BrokenBarrierException e) {
				e.printStackTrace();
			}
			System.out.println("thread" + Thread.currentThread().getName() + "final round started.....");
			if (productCount.addAndGet(-2)==0){
				System.out.println("thread" + Thread.currentThread().getName() + "get last product......");
			}else {
				System.out.println("thread" + Thread.currentThread().getName() + "didn't get last product......");
			}
			
		}
	}

}
