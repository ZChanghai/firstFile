import java.util.concurrent.Callable;

import sun.misc.Unsafe;




class Task implements Callable<Integer>{
	private int sum = 0;
	
	public Task(int sum){
		this.sum = sum;
	}
	 @Override
    public Integer call() throws Exception {
        System.out.println("subthread is processing");
        Thread.sleep(3000);
        for(int i=0;i<100;i++){
        	if (Thread.interrupted()){
        		return sum;
        	}
            sum += i;
        }
        return sum;
    }
   
}
