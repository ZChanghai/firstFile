
public class CommonString {
	
	public static String findCommonString(String str1, String str2){
		String aa = null;
		String longString = null;
		String shortString = null;
		if (str1.length()>str2.length()){
			longString = str1;
			shortString = str2;
		}else{
			longString = str2;
			shortString = str1;
		}
		for (int i = 0;i<shortString.length();i++){
			for (int start = 0,end = shortString.length() -i;end <= shortString.length();start++,end++){
				String subString = shortString.substring(start, end);
				if (longString.contains(subString)){
					return subString;
				}
			}
		}
		return null;
	}
	
	public static String findCommonStringByMatrix(String str1,String str2){
		int horizonLength = str1.length();
		int verticalLength = str2.length();
		int [] topLine = new int[horizonLength];
		int [] currentLine  = new int [topLine.length];
		char a =' ';
		int maxValue = 0;
		int maxIndex = 0;
		
		for (int i =0;i<verticalLength;i++){
			a = str2.charAt(i);
			for (int j = 0;j<str1.length();j++){
				if (a == str1.charAt(j)){
					if (j==0){
						currentLine[j] =1;
					}else{
						currentLine[j] = topLine[j-1]+1;
					}
				}else{
					currentLine[j] =0;
				}
				if (currentLine[j]>maxValue){
					maxValue = currentLine[j];
					maxIndex = j;
				}
			}
			for (int k=0;k<str1.length();k++){
				topLine[k] = currentLine[k];
				currentLine[k]=0;
			}
		}
		
		return str1.substring(maxIndex-maxValue+1, maxIndex+1);
	}

	public static void main(String[] args) {
		String aa = "abcdefghi";
		String bb = "ererereabced";
		String aaa = "abc";
		String ccc = "cbabc";
		System.out.println(CommonString.findCommonString(aa, bb));
		System.out.println(CommonString.findCommonStringByMatrix(aaa, ccc));
	}

}
