package test;

public class solution4220V extends solution4110V implements target {
	public String get220V(){
		return "it is 220v solution!!!";
	}
	
	public static void main(String[] args) {
		solution4220V s220 = new solution4220V();
		System.out.println(s220.get110V());
		System.out.println(s220.get220V());
	}
}
