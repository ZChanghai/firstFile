package test;

public interface target {
	
	public String get110V();
	
	public String get220V();

}
