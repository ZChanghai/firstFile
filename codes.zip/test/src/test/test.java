package test;

import io.netty.util.internal.SystemPropertyUtil;

import java.lang.reflect.Proxy;

import RPCSample.calcuate;

public class test {
	
	public void sayHello(){
		System.out.println("test6");
	}

	public static void main(String[] args) {
//		String aa = "PageTitle=Article Title;Language=en;PublishingDate=24-Mar-2017;Author=[Jonathan  Main, Alexa L Kuzmich];AuthorID=[55706611, 35507606];contentType=blog;uuid=1123;";
//		String[] objparts = aa.split(";");
//		for (String element : objparts) {
//			String[] objmeta = element.split("=");
//			if (objmeta != null && objmeta[0] != null
//					&& !objmeta[0].isEmpty() && objmeta[1] != null
//					&& !objmeta[1].isEmpty()) {
//				
//			}
//		}
//		String a = "14";
//		int b = Integer.parseInt(a);
//		String limit = String.valueOf((18 - 9)%9);
//		
//		System.out.println(limit);
//		implementTarget target  = new implementTarget();
		
//		target ee = (target)Proxy.newProxyInstance(target.getClass().getClassLoader(), target.getClass().getInterfaces(), new proxyHandle(target));
		proxyHandle proxy = new proxyHandle(new implementTarget());
		target ee = (target)proxy.getProxyInstance();
		
		ee.get110V();
		
		ee.get220V();
		
		try {
			calcuate c = (calcuate) Class.forName("RPCSample.calcuate").newInstance();
			System.out.println(c.plusAction(1, 2));
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ClassLoader loader = target.class.getClassLoader();	
		while(loader != null) {
			System.out.println(loader);
			loader = loader.getParent();
		}
		System.out.println(loader);
		int array[] =  {9,5,4,3,1};
		for (int i= 0;i<array.length;i++){
			for (int j = i+1;j<array.length;j++){
				if (array[i]>array[j]){
					int temp = array[j];
					array[j] = array[i];
					array[i] = temp;
				}
			}
		}
		
		for (int k = 0;k <array.length;k++){
			System.out.println(array[k]);
		}
		
		int numberCount = (int) (((long) Integer.MAX_VALUE + 1) / 2);
		System.out.println("numberCount"+numberCount);
	}

}
