package test;

public class implementTarget implements target {

	@Override
	public String get110V() {
		
		return "this is 110V";
	}
	
	@Override
	public String get220V() {
		
		return "this is 220V";
	}

	
	public static void main(String[] args) {
		implementTarget target = new implementTarget();
		System.out.println(target.get220V());
	}
}
