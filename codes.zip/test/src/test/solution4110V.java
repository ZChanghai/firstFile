package test;

public class solution4110V {
	
	public String get110V(){
		return "it is 110V output!!!";
		
	}

}
