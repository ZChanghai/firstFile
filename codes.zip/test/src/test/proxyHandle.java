package test;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class proxyHandle implements InvocationHandler {
	
	private Object object;
	
	public proxyHandle(Object aa){
		object = aa;
	}
	
	public Object getProxyInstance(){
		return Proxy.newProxyInstance(object.getClass().getClassLoader(), object.getClass().getInterfaces(), this);
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		if (method.getName().indexOf("110")>0){
			System.out.println("inside 110");
		}else if (method.getName().indexOf("220")>0){
			System.out.println("inside 220");
		}
		System.out.println(method.invoke(object, args));
		if (method.getName().indexOf("110")>0){
			System.out.println("exit 110");
		}else if (method.getName().indexOf("220")>0){
			System.out.println("exit 220");
		}
		return null;
	}

}
