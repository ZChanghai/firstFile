package test;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;


public class testDemo {

	public static void main(String[] args) {
		Map<String, String> map = new LinkedHashMap<String, String>(16,0.75f,true);
	    map.put("apple", "apple");
	    map.put("watermelon", "watermelon");
	    map.put("banana", "banana");
	    map.put("peach", "peach");

	    map.get("banana");
	    map.get("apple");
	    map.get("apple");
	    map.get("banana");
	    map.get("banana");

	    Iterator iter = map.entrySet().iterator();
	    while (iter.hasNext()) {
	        Entry entry = (Entry) iter.next();
	        System.out.println(entry.getKey() + "=" + entry.getValue());
	    }
		
	}

}
