
public class testClass {
	
	public void say(){
		System.out.println("xx");
	}

}
