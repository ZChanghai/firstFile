import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.atomic.AtomicInteger;

public class CyclicBarrierTest {
	public static AtomicInteger i = new AtomicInteger(1);
	public static void main(String[] args) {
		int N = 4;
		CyclicBarrier barrier = new CyclicBarrier(N);
		for (int i = 0; i < N; i++)
			new Writer(barrier).start();
	}

	static class Writer extends Thread {
		private CyclicBarrier cyclicBarrier;

		public Writer(CyclicBarrier cyclicBarrier) {
			this.cyclicBarrier = cyclicBarrier;
		}

		@Override
		public void run() {
			System.out.println("thread" + Thread.currentThread().getName()
					+ "writing......");
			try {
				int waitingTIme1 =1000 * i.incrementAndGet();
				System.out.println(waitingTIme1);
				System.out.println("after change:" +i);
				Thread.sleep(waitingTIme1);
				System.out.println("thread" + Thread.currentThread().getName()
						+ "write done......");
				cyclicBarrier.await();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (BrokenBarrierException e) {
				e.printStackTrace();
			}
			System.out.println("thread"+Thread.currentThread().getName()+ "is pending");
//			System.out.println(i.getAndAdd(-1000));
		}
	}

}
