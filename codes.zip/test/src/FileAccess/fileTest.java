package FileAccess;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class fileTest {

	public static void main(String[] args) {
		RandomAccessFile ra = null;
		String line = null;
		try {
			ra = new RandomAccessFile("src/FileAccess/test.txt","rw");
			while ((line = ra.readLine()) != null){
				System.out.println(line);
			}
			System.out.println(ra.length());
			System.out.println(ra.getFilePointer());
			//ra.writeUTF("fasdfasfsf.asfadfsfa.asdfsaf\n");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				if (ra != null)
				ra.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}

}
