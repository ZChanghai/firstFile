package FileAccess;

import io.netty.util.CharsetUtil;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class writeLog {

	public static void main(String[] args) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				RandomAccessFile ra = null;
				try {
					ra = new RandomAccessFile("src/FileAccess/test.txt","rw");
					ra.seek(ra.length());
					if (ra.length()>0){
						ra.write(0x0d);
					}
					ra.write("test1.test2.test3".getBytes(CharsetUtil.UTF_8));
//					ra.write(0x0a);
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}finally{
					try {
						if (ra != null)
						ra.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			}).start();

	}

}
