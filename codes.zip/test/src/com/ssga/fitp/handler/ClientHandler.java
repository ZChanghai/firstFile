package com.ssga.fitp.handler;

import com.ssga.fitp.model.FitpResponse;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

public class ClientHandler extends SimpleChannelInboundHandler<FitpResponse> {
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, FitpResponse msg) throws Exception {
        System.out.println(msg.getKey() + ": " + msg.getValue());
    }
}
