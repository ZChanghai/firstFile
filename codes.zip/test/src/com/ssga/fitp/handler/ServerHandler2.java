package com.ssga.fitp.handler;

import com.ssga.fitp.Data.FundData;
import com.ssga.fitp.model.FitpRequest;
import com.ssga.fitp.model.FitpResponse;
import com.ssga.fitp.model.Fund;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

import java.util.List;

public class ServerHandler2 extends SimpleChannelInboundHandler<FitpRequest> {

    private List<Fund> data = new FundData().getFundList();

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, FitpRequest msg) throws Exception {
        String code = msg.getCode();
        String key = msg.getInfoKey();
        String value = "";
        for (Fund fund : data) {
            if (fund.getCode().equals(code)) {
                value = fund.getMap().get(key);
                break;
            }
        }
        if (null == value) {
            value = "key doesn't exist";
        }
        if ("".equals(value)) {
            value = "code doesn't exist";
        }
        FitpResponse response = new FitpResponse(key, value);
        ctx.writeAndFlush(response);
    }
}
