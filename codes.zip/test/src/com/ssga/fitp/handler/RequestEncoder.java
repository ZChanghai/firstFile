package com.ssga.fitp.handler;

import com.ssga.fitp.model.FitpRequest;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import io.netty.util.CharsetUtil;

public class RequestEncoder extends MessageToByteEncoder<FitpRequest> {

    @Override
    protected void encode(ChannelHandlerContext ctx, FitpRequest msg, ByteBuf out) throws Exception {
        byte[] code = msg.getCode().getBytes(CharsetUtil.UTF_8);
        byte[] infoKey = msg.getInfoKey().getBytes(CharsetUtil.UTF_8);
        int codeLength = msg.getCodeLength();
        int keyLength = msg.getKeyLength();
        out.writeInt(codeLength);
        out.writeInt(keyLength);
        out.writeBytes(code);
        out.writeBytes(infoKey);
    }
}
