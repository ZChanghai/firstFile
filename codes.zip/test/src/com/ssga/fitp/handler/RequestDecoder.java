package com.ssga.fitp.handler;

import com.ssga.fitp.model.FitpRequest;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.util.CharsetUtil;

import java.util.List;

public class RequestDecoder extends ByteToMessageDecoder {

    private enum State {
        Header,
        Body
    }

    private State state = State.Header;
    private int codeLength;
    private int keyLength;
    private int bodyLength;

    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
        switch (state) {
            case Header:
                if (in.readableBytes() < 4) {
                    return;
                }
                codeLength = in.readInt();
                keyLength = in.readInt();
                bodyLength = codeLength + keyLength;
                state = State.Body;
            case Body:
                if (in.readableBytes() < bodyLength) {
                    return;
                }
                String code = "";
                ByteBuf codeBuf = in.readBytes(codeLength);
                code = codeBuf.toString(CharsetUtil.UTF_8);
                String key = "";
                ByteBuf keyBuf = in.readBytes(keyLength);
                key = keyBuf.toString(CharsetUtil.UTF_8);
                out.add(new FitpRequest(code, key));
                state = State.Header;
        }
    }
}
