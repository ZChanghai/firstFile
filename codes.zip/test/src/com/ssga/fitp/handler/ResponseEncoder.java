package com.ssga.fitp.handler;

import com.ssga.fitp.model.FitpResponse;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import io.netty.util.CharsetUtil;

public class ResponseEncoder extends MessageToByteEncoder<FitpResponse> {
    @Override
    protected void encode(ChannelHandlerContext ctx, FitpResponse msg, ByteBuf out) throws Exception {
        byte[] key = msg.getKey().getBytes(CharsetUtil.UTF_8);
        byte[] value = msg.getValue().getBytes(CharsetUtil.UTF_8);
        int keyLength = msg.getKeyLength();
        int valueLength = msg.getValueLength();
        out.writeInt(keyLength);
        out.writeInt(valueLength);
        out.writeBytes(key);
        out.writeBytes(value);
    }
}
