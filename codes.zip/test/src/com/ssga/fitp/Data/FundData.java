package com.ssga.fitp.Data;

import com.ssga.fitp.model.Fund;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FundData {
    private List<Fund> fundList = new ArrayList<>();

    public FundData() {
        Map<String, String> map = new HashMap<>();
        map.put("performance", "0.10%");
        map.put("assets", "$38,062,770,453");
        map.put("asofdate", "08/18/2017");
        map.put("nav", "$1.00");
        map.put("factor", "0.000025");
        Fund fund = new Fund("SAHXX", map);
        fundList.add(fund);
        fund = new Fund("GVMXX", map);
        fundList.add(fund);
        fund = new Fund("GVVXX", map);
        fundList.add(fund);
        fund = new Fund("SAMXX", map);
        fundList.add(fund);
        fund = new Fund("SALXX", map);
        fundList.add(fund);
        Map<String, String> map1 = new HashMap<>();
        map1.put("nav", "$1.00");
        fund = new Fund("ZCH",map1);
        fundList.add(fund);
    }

    public List<Fund> getFundList() {
        return fundList;
    }
}
