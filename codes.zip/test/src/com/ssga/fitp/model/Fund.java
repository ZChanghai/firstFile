package com.ssga.fitp.model;

import java.util.Map;

public class Fund {
    private String code;
    private Map<String, String> map;

    public Fund(String code, Map<String, String> map) {
        this.code = code;
        this.map = map;
    }

    public String getCode() {
        return code;
    }

    public Map<String, String> getMap() {
        return map;
    }
}
