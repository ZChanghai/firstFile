package com.ssga.fitp.model;

public class FitpResponse {
    private final String key;
    private final String value;
    private final int keyLength;
    private final int valueLength;

    public FitpResponse(String key, String value) {
        this.key = key;
        this.value = value;
        this.keyLength = key.getBytes().length;
        this.valueLength = value.getBytes().length;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public int getKeyLength() {
        return keyLength;
    }

    public int getValueLength() {
        return valueLength;
    }
}
