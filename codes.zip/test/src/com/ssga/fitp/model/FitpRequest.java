package com.ssga.fitp.model;

import io.netty.util.CharsetUtil;

public class FitpRequest {
    private final int codeLength;
    private final int keyLength;
    private String code;
    private String infoKey;

    public void setInfoKey(String infoKey) {
		this.infoKey = infoKey;
	}

	public FitpRequest(String code, String infoKey) {
        this.code = code;
        this.infoKey = infoKey;
        this.codeLength = code.getBytes(CharsetUtil.UTF_8).length;
        this.keyLength = infoKey.getBytes(CharsetUtil.UTF_8).length;
    }

    public String getCode() {
        return code;
    }

    public String getInfoKey() {
        return infoKey;
    }

    public int getCodeLength() {
        return codeLength;
    }

    public int getKeyLength() {
        return keyLength;
    }
    
    public void setCode(String code1){
    	this.code = code1;
    }
}
