import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;


public class ThreadPoolExecutorTest {
	volatile int tout = 2;
	static int sum = 0;
	
	public int getLatesetTimeOut(){
		return tout;
	}
	
	public void setLatesetTimeout(){
		 tout =tout +2;
	}
	
	public void executeFuture(int times,Future<Integer> future){
		int i = times;
		try {
			System.out.println(times+" invoke time:" +tout);
			System.out.println(future.get(tout, TimeUnit.SECONDS));
			sum = future.get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} catch (TimeoutException e) {
			this.setLatesetTimeout();
//			future.cancel(true);
//			System.out.println(future.isCancelled());
//			System.out.println(future.isDone());
			i++;
			this.executeFuture(i, future);
		}
	}

	public static void main(String[] args) {
		ThreadPoolExecutorTest test = new ThreadPoolExecutorTest();
		ExecutorService cachedThreadPool = Executors.newCachedThreadPool();
		ExecutorService schedule = Executors.newScheduledThreadPool(1);
		for (int i = 0; i < 3; i++) {  
			final int index = i;  
			try {  
				Thread.sleep(index * 1000);  
			} catch (InterruptedException e) {  
				e.printStackTrace();  
			}  
//			cachedThreadPool.execute(
//				new Runnable() {  
//				    public void run() {  
//				    	System.out.println(Thread.currentThread().getName());
//				    	System.out.println(index);  
//				    }  
//				}
//			);
//		List <Task> taskList = new ArrayList<Task>();
//		for (int i = 0;i<10;i++){
			
			Task task  = new Task(sum);
//			taskList.add(task);
			Future<Integer> future = cachedThreadPool.submit(task);
			test.executeFuture(1, future);
		}
//		try {
//			List<Future<Integer>> result = cachedThreadPool.invokeAll(taskList);
//			for (int i = 0 ;i<result.size();i++){
//				if (result.get(i).isDone()){
//					System.out.println("the "+i +"thread was processd");
//					System.out.println(result.get(i).get().toString());
//				}
//			}
//		} catch (InterruptedException | ExecutionException e) {
//			e.printStackTrace();
//		}
			
//	   }
		cachedThreadPool.shutdown();
			
	}

}
