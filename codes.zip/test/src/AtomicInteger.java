import sun.misc.Unsafe;

public class AtomicInteger implements java.io.Serializable {
	    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		// setup to use Unsafe.compareAndSwapInt for updates
	    static long valueOffset;
	    private volatile int value;
	    public final int get() {return value;}
		public static void main(String[] args) {
			try {
	            valueOffset = Unsafe.getUnsafe().objectFieldOffset
	                (AtomicInteger.class.getDeclaredField("value"));
	            System.out.println(valueOffset);
	        } catch (Exception ex) { throw new Error(ex); }
			AtomicInteger atomic = new AtomicInteger();
			atomic.value = 12;
			System.out.println(atomic.valueOffset);
		}
}
