package concurrentShopping;

import java.util.concurrent.atomic.AtomicInteger;

public class Products {
	
	public static AtomicInteger counts = new AtomicInteger(1);
	
	public static AtomicInteger IPhone = new AtomicInteger(2);
	
	public static AtomicInteger IPad = new AtomicInteger(3);
	
}
