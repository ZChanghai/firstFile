package concurrentShopping;

import java.util.concurrent.Semaphore;

public class executeShopProduct extends Thread {
	
	private static Semaphore s = new Semaphore(5);
	
	private int requestCount;
	
	public executeShopProduct(int requestCount) {
		this.requestCount = requestCount;
	}
	
	@Override
	public void run() {
		try {
			s.acquire();
			System.out.println("thread" + Thread.currentThread().getName()+ " acquire shopping execution...........");
			int existingCount = Products.counts.get();
			int existingIphone = Products.IPhone.get();
			int existingIPad = Products.IPad.get();
			if (existingCount> 0){
				if (existingCount < requestCount){
					if (Products.counts.getAndSet(0)==existingCount){
						System.out.println("thread" + Thread.currentThread().getName()+ " didn't shopped "+requestCount+" product and but shopped final "+existingCount);
					}else{
						System.out.println("thread" + Thread.currentThread().getName()+ " didn't shopped final "+existingCount+ " product!!");
					}
				}else{
					if (Products.counts.compareAndSet(existingCount, existingCount-requestCount)){
						System.out.println("thread" + Thread.currentThread().getName()+ " shopped " +requestCount +" products and remains");
					}else{
						System.out.println("thread" + Thread.currentThread().getName()+ " didn't shopped "+requestCount+" product");
					}
				}
			}else{
				System.out.println("thread" + Thread.currentThread().getName()+ " didn't shopped "+requestCount+" product");
			}
			System.out.println("thread" + Thread.currentThread().getName()+ " release shopping execution...........");
			CountdownLatch.latch.countDown();
			s.release();
		} catch (Exception e) {
		}finally{
		}
	}

}
