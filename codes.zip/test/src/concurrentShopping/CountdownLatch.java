package concurrentShopping;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class CountdownLatch {
	final static CountDownLatch latch = new CountDownLatch(10);
	
	public static ThreadPoolExecutor cachedThreadPool = (ThreadPoolExecutor)Executors.newFixedThreadPool(10);
	
	public static void triggerReleasePool(){
		try {
			latch.await();
//			if (cachedThreadPool.getActiveCount() == cachedThreadPool.getPoolSize()){
				cachedThreadPool.shutdown();
				System.out.println("thread pool was released.....................");
//			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
