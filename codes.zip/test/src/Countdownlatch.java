import java.util.concurrent.CountDownLatch;


public class Countdownlatch extends Thread{
	final static CountDownLatch latch = new CountDownLatch(2);
	 @Override
     public void run() {
		 try {
             System.out.println("sub-thread"+Thread.currentThread().getName()+"processing");
             Thread.sleep(3000);
             System.out.println("sub-thread"+Thread.currentThread().getName()+"completed");
             latch.countDown();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
     }

	public static void main(String[] args) {
		
		System.out.println("waiting for 2 thread processing...");
		Countdownlatch thread1 = new Countdownlatch();
        Countdownlatch thread2 = new Countdownlatch();
        thread1.start();
        try {
			thread1.join();
			System.out.println("middle......");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        thread2.start();
        try {
			latch.await();
			System.out.println("2 thread process completed....");
	        System.out.println("handle main thread.......");
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
